package com.example.animaladoptionapp;

public class UserClass {

    public String name, email, doB, gender, mobile;

    public UserClass() {
    }

    public UserClass(String name, String email, String doB, String gender, String mobile) {
        this.name = name;
        this.email = email;
        this.doB = doB;
        this.gender = gender;
        this.mobile = mobile;
    }
}
