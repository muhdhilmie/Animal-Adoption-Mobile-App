package com.example.animaladoptionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserAdopt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_adopt);
    }
}